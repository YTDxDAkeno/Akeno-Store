# PS5-Ziel

Der native Katalog entsteht in C und SDL2. Er liest dieselben Katalog- und Bibliotheksdaten wie der Host-Hub. Der Quellcode verwendet die SDL-Ereignis- und Rendering-APIs für Navigation und Anzeige. Für das PS5-Target brauchst du ein für deine Konsole autorisiertes SDK mit Compiler und einer dazu passenden SDL2-Bibliothek.

## Build mit Ziel-SDK

Lege eine eigene Make-Datei außerhalb des Repositorys an. Hinterlege dort die folgenden Variablen mit den vom SDK dokumentierten Werten.

| Variable | Inhalt |
| --- | --- |
| `PS5_CC` | Absoluter Pfad zum Compiler oder Compiler-Wrapper des Ziel-SDKs |
| `PS5_CPPFLAGS`, `PS5_CFLAGS` | Zielarchitektur, Sysroot und weitere Vorgaben des SDKs |
| `PS5_SDL2_CFLAGS` | Include-Pfade der SDL2-Version für das Ziel |
| `PS5_LDFLAGS`, `PS5_SDL2_LIBS` | Zielbibliotheken, Linkeroptionen und SDL2 inklusive Transitivabhängigkeiten |

```sh
make -f Makefile -f /pfad/zur/sdk.mk ps5
```

Der Linker schreibt bei Erfolg `dist/ps5/akeno-hub.elf`. Installation, Signatur und Registrierung erfordern das dokumentierte Paketverfahren der jeweiligen Entwicklungsumgebung. Eine auf dem Host erzeugte SDL-Binärdatei gehört ausschließlich auf den Host.

## Konsolentests

Führe die Tests auf einer autorisierten Konsole durch und erfasse Firmware, SDK-Version und Binärhash mit den Ergebnissen.

1. Ziel-Binärdatei erzeugen und die Abhängigkeiten mit dem Ziel-SDK prüfen.
2. Paket im autorisierten Workflow erzeugen, installieren und dessen Einstiegspunkt starten.
3. Bildausgabe, Tastennavigation, DualSense, Hotplug und saubere Rückkehr prüfen.
4. Katalog und Bibliothek laden. Leere, teilweise und aktualisierte Dateien einbeziehen.
5. Erst nach Integration des nativen Installers TLS, Hashfehler, fehlenden Speicher, Abbruch und Fehler während der Aktualisierung prüfen.
6. Für jeden integrierten Runner Start, Spielbarkeit, Spielende und Rückkehr mit mehreren autorisierten Spielen separat messen.
7. Erst nach einem verfügbaren Registrierungs-API-Vertrag Verknüpfung, Aktualisierung und Entfernung mit mehreren Installationen prüfen.

## Zielobjekte separat prüfen

```sh
make ps5-objects PS5_CLANG=clang PS5_SYSROOT=/pfad/zum/target
readelf -h dist/ps5/obj/main.o
```

Das Ziel kompiliert beide C-Dateien gegen die SDL2- und System-Header für PS5. Es erwartet `include` und `user/homebrew/include/SDL2` im angegebenen Sysroot. Die Ausgabedateien sind relocatable ELF-Objekte für x86-64. Dieser Schritt benötigt weder einen Startcode noch eine Verbindung zur Konsole. In der Cloud wurde er mit Clang 19.1.7 und dem verifizierten PacBrew-v0.40.2-Headerbaum ausgeführt. Der WSL-Wrapper unterstützt denselben Schritt mit `-Target ps5-objects` und einer Make-Datei für `PS5_SYSROOT` und optional `PS5_CLANG`.
